import React, { useEffect, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import Header from "../../components/Header";
import Footer from "../../components/Footer";
import Formulario from "../../components/Formulario";
import { useDispatch, useSelector } from "react-redux";

function Detalles() {
  const { id } = useParams("id");

  const [producto, setProducto] = useState({})

  const peticion = async (id) => {
    try {
      const url = `https://flutter-varios-1db01-default-rtdb.firebaseio.com/products/${id}.json`;

      let petcion_get = await fetch(url);
      let respuesta = await petcion_get.json();

      respuesta['id'] = id
      setProducto(respuesta)
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    return () => {
      peticion(id);
    };
  }, []);

  return (
    <div>
      <Header />

      <div className="container justify-content-center">
        {producto == null ? (
          <div className="spinner-border text-success" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        ) : (
          <>
            <div className="card card-detail">
              <img
                src={producto.picture}
                className="card-img-top"
                alt={producto.name}
              />
              <div className="card-body text-center">
                <h5 className="card-title">{producto.name}</h5>
                <p className="card-text">{producto.price}</p>
                {producto.available ? (
                  <span className="bg-success rounded-pill p-2">Available</span>
                ) : (
                  <span className="mb bg-danger rounded-pill p-2">Off</span>
                )}
              </div>
            </div>

            <div className="card mt-2 mb-2">
              <Formulario producto={producto} />
            </div>
          </>
        )}
      </div>

      <Footer />
    </div>
  );
}

export default Detalles;
