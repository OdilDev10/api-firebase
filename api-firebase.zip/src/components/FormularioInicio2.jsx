import React, { useRef } from "react";

function FormularioInicio2() {
  const email_input = useRef("");
  const password_input = useRef("");

  const handleSubmit = (event) => {
    event.preventDefault();
    const email = email_input.current.value;
    const password = password_input.current.value;


    
    console.log(name);
  };

  return (
    <form className="form p-4 text-center" onSubmit={handleSubmit}>
      <div className="form-floating mb-3">
        <input
          type="text"
          defaultValue=""
          ref={email_input}
          className="form-control"
          placeholder="Email"
        />
        <label for="floatingInputDisabled">Email</label>
      </div>

      <div className="form-floating mb-3">
        <input
          type="password"
          defaultValue=""
          ref={password_input}
          className="form-control"
          placeholder="Password"
        />
        <label for="floatingInputDisabled">Password</label>
      </div>

      <button className="btn btn-outline-warning w-50" type="submit">
        Submit
      </button>
    </form>
  );
}

export default FormularioInicio2;
