import React from 'react'
import reactLogo from "../assets/react.svg";
import viteLogo from "/vite.svg";

function Header() {
  return (
    <>
                <header className="header text-center">
          <h1 className="title">Consumo API Firebase</h1>
          <div className="img-header m-4">
            <img
              src="https://www.gstatic.com/mobilesdk/160503_mobilesdk/logo/2x/firebase_28dp.png"
              alt="Firebase"
            />
            <img src={reactLogo} alt="REACT" />
            <img src={viteLogo} alt="VITE" />
          </div>
        </header>
    </>
  )
}

export default Header