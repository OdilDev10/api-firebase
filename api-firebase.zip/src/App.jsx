import { useEffect, useState } from "react";
import { Button, Modal } from 'react-bootstrap';

import { useSelector, useDispatch } from 'react-redux';
import { addAllProducts } from "./store/allProducts";

import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import { Link } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import Formulario from "./components/Formulario";

function App() {
  const [products, setProducts] = useState([]);

  // modal
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  // store
  const allProducts = useSelector((state) => state.all_products);
  const dispatch = useDispatch();

  const peticion = async () => {
    const url =
      "https://flutter-varios-1db01-default-rtdb.firebaseio.com/products.json";

    let petcion_get = await fetch(url);
    let respuesta = await petcion_get.json();
    let respuesta_array = Object.values(respuesta);
    let ids = Object.keys(respuesta);

    const productsWithIds = respuesta_array.map((product, index) => {
      return { ...product, id: ids[index] };
    });

    setProducts(productsWithIds);
    dispatch(addAllProducts(productsWithIds));
    console.log("ESTO ESTA LOCO?")
    console.log("PRODUCTOS DE APP: ", allProducts, 'PRODUCTOS: ', products)

  };

  useEffect(() => {
    return () => {
      peticion();
    };
  }, []);

  // useEffect(() => {
  //   console.log("PRODUCTOS DE APP: ", allProducts)
  // }, [allProducts])
  

  return (
    <>
      <div className="container">
      <Header/>

        <main className="main" id="main">
          <div
            className="row justify-content-center p-4 gap-2"
            id="row_tarjetas"
          >
            {products == null ? (
              <div className="spinner-border text-success" role="status">
                <span className="visually-hidden">Loading...</span>
              </div>
            ) : (
              products.map((item) => {
                return (
                  
                    <div className="card col-3 " key={item.id}>
                      {item.available ? (
                  <span className="m-1 bg-success rounded-pill p-2">Available</span>
                ) : (
                  <span className="m-1 bg-danger rounded-pill p-2">Off</span>
                )}
                      <img
                        src={item.picture}
                        className="card-img-top"
                        alt={item.name}
                      />
                      <div className="card-body">
                        <h5 className="card-title">{item.name}</h5>
                        <p className="card-text">{item.price}</p>
                        <Link
                          to={"/detalles/" + item.id}
                          className="btn btn-primary w-100"
                        >
                          Detalles
                        </Link>
                      </div>
                    </div>
                  
                );
              })
            )}
          </div>
        </main>

      <div className="contenedor_btn">
        <div className="contenedor_btn_izquierda">
          <Button variant="primary" className="btn_contenido rounded-circle" onClick={handleShow}><span>+</span></Button>
          <Link className="btn_contenido rounded-circle" to={'/inicio'} ><span><i className="fas fa-user"></i></span></Link>


        </div>


        <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Crear Producto</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <Formulario/>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          
        </Modal.Footer>
      </Modal>


      </div>

      </div>


      <Footer/>


    </>
  );
}

export default App;
