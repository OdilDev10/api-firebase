import React, { useRef, useState } from "react";


function FormularioInicio() {
  const name_input = useRef("");
  const age_input = useRef("");
  const email_input = useRef("");
  const password_input = useRef("");
  const passwordConfirm_input = useRef("");



  const handleSubmit = async (event) => {
    event.preventDefault();
    const name = name_input.current.value;
    const age = age_input.current.value;
    const email = email_input.current.value;
    const password = password_input.current.value;
    const passwordConfirm_input = passwordConfirm_input.current.value;

    let url = "https://flutter-varios-1db01-default-rtdb.firebaseio.com/users.json"

 

    console.log(name);
  };

  return (
    <form className="form p-4 text-center" onSubmit={handleSubmit}>
      <div className="form-floating mb-3">
        <input
          type="text"
          defaultValue=""
          ref={name_input}
          className="form-control"
          placeholder="Name"
        />
        <label for="floatingInputDisabled">Name</label>
      </div>

      <div className="form-floating mb-3">
        <input
          type="text"
          defaultValue=""
          ref={age_input}
          className="form-control"
          placeholder="Age"
        />
        <label for="floatingInputDisabled">Age</label>
      </div>
      <div className="form-floating mb-3">
        <input
          type="text"
          defaultValue=""
          ref={email_input}
          className="form-control"
          placeholder="Email"
        />
        <label for="floatingInputDisabled">Email</label>
      </div>

      <div className="form-floating mb-3">
        <input
          type="password"
          defaultValue=""
          ref={password_input}
          className="form-control"
          placeholder="Password"
        />
        <label for="floatingInputDisabled">Password</label>
      </div>

       
      <div className="form-floating mb-3">
        <input
          type="password"
          defaultValue=""
          ref={passwordConfirm_input}
          className="form-control"
          placeholder="Password Confirm"
        />
        <label for="floatingInputDisabled">Password Confirm</label>
      </div>

      <button className="btn btn-outline-warning w-50" type="submit">
        Submit
      </button>
    </form>
  );
}

export default FormularioInicio;
