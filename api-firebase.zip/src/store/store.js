import {configureStore} from "@reduxjs/toolkit"
import productSlice  from "./productSlice"
import { allProductSlice } from "./allProducts"


export const store = configureStore({
    reducer: {
        product: productSlice,
        all_products: allProductSlice,

    }
})