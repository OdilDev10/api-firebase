import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    name: "",
    price: 0,
    picture: "",
    available: false
}


export const productSlice = createSlice({
    name: "product",
    initialState,
    reducers: {
        addProduct: (state, action) => {
            const {name, price, picture, available} = action.payload;
            state.name = name
            state.price = price
            state.picture = picture
            state.available = available 
        },
        changePicture: (state, action) => {
            state.picture = action.payload
        }
    }
})

export const {addProduct, changePicture} = productSlice.actions
export default productSlice.reducer