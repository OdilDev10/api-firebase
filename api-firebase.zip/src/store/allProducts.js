import { createSlice } from "@reduxjs/toolkit";

const initialState = []

export const allProductSlice = createSlice({
    name: "all_products",
    initialState,
    reducers: {
        addAllProducts: (state, action) => {
            state = action.payload
            console.log('LLEGO A EL STORE ',action.payload)
        },
    }
})

export const {addAllProducts} = allProductSlice.actions
export default allProductSlice.reducer